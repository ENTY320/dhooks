from .client import Webhook
from .file import File
from .embed import Embed

__title__ = 'dhooks'
__author__ = 'kyb3r'
__license__ = 'MIT'
__version__ = '1.1.4'
